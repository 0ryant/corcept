---
title: Completed Tasks
description: Completed subtasks for the generated scaffold.
seo:
  title: Completed Tasks - Corcept Runtime
  description: Completed subtasks for the generated scaffold.
  keywords: ['tasks', 'completed', 'subtasks', 'Corcept', 'Claude Code', 'Rust']
tags: ['tasks', 'completed', 'subtasks']
status: complete
---


# Completed Tasks

| ID | Task | Status | Artifact |
|---|---|---:|---|
| ST-001 | Define governance product shape | complete | `docs/adr/0001-doctrine-first-runtime.md` |
| ST-002 | Create Rust workspace | complete | `Cargo.toml`, `crates/*` |
| ST-003 | Implement shared types | complete | `crates/corcept-types` |
| ST-004 | Implement ledger hash chain | complete | `crates/corcept-ledger` |
| ST-005 | Implement pre-tool guards | complete | `crates/corcept-guards` |
| ST-006 | Implement doctrine loader | complete | `crates/corcept-doctrine` |
| ST-007 | Implement memory promotion | complete | `crates/corcept-memory` |
| ST-008 | Implement runtime orchestration | complete | `crates/corcept-runtime` |
| ST-009 | Implement CLI | complete | `crates/corcept-cli` |
| ST-010 | Implement installer binary | complete | `crates/create-corcept` |
| ST-011 | Write plugin manifest | complete | `plugins/corcept/.claude-plugin/plugin.json` |
| ST-012 | Write Claude Code skills | complete | `plugins/corcept/skills/*` |
| ST-013 | Write bounded agents | complete | `plugins/corcept/agents/*` |
| ST-014 | Wire hooks | complete | `plugins/corcept/hooks/hooks.json` |
| ST-015 | Write hook wrappers | complete | `plugins/corcept/bin/*` |
| ST-016 | Write schemas | complete | `schemas/*` |
| ST-017 | Write root docs | complete | root `*.md` |
| ST-018 | Write ADRs | complete | `docs/adr/*` |
| ST-019 | Write subtask files | complete | `docs/subtasks/*` |
| ST-020 | Package scaffold zip | complete | generated artifact |
| ST-021 | Harden guard classifiers and ledger append path | complete | `docs/adr/0013-hardened-command-classification.md`, `crates/corcept-guards`, `crates/corcept-ledger` |


## Completed in v0.4.0-fullship

- ST-023 expanded external benchmark adapters — completed.
- ST-024 policy-aligned guard benchmark — completed.
- ST-025 single fullship zip — completed.
