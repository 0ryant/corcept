#!/usr/bin/env bash
set -euo pipefail
python -m corcept_eval preflight --out results/preflight.json
python -m corcept_eval list-benchmarks --out results/benchmark-registry.json
python -m corcept_eval write-runbook --out results/external-runbook.md
