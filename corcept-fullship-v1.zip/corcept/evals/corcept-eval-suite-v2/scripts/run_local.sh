#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m corcept_eval run-local --out results/local
python -m corcept_eval preflight --out results/preflight.json
