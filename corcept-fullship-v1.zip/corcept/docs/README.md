---
title: Corcept Docs Index
description: Documentation index for Corcept Runtime.
seo:
  title: Corcept documentation index
  description: Index of ADRs, subtasks, runtime docs, plugin docs, and governance material.
  keywords: [Corcept, docs, ADR, Claude Code, Rust]
tags: [docs, index, corcept]
status: complete
---

# Docs Index

- `adr/` accepted architecture decisions.
- `subtasks/` completed implementation records.
- Root docs cover architecture, install, usage, API, plugin, governance, testing, security, release, roadmap, tasks, and changelog.
