---
title: Corcept Runtime
description: Doctrine-first Claude Code governance runtime with Rust hooks, bounded agents, audit ledger, memory promotion, and plugin packaging.
seo:
  title: Corcept Runtime - governed Claude Code hooks, agents, memory, and audit ledger
  description: A Rust workspace and Claude Code plugin scaffold for safe agentic development: PreToolUse guards, PostToolUse audit, Stop gates, doctrine, memory promotion, and bounded subagents.
  keywords:
    - Claude Code plugin
    - Claude Code hooks
    - AI coding governance
    - agent audit ledger
    - Rust CLI scaffold
    - doctrine memory runtime
tags: [claude-code, rust, hooks, agents, plugin, governance, audit-ledger, memory, doctrine, corcept]
status: hardened-scaffold-complete
---

# Corcept Runtime

Corcept is a governed Claude Code runtime: a Rust workspace plus a Claude Code plugin scaffold that turns raw agentic coding into a bounded, auditable, doctrine-backed workflow.

It is intentionally not a giant prompt pack. The system is built around a smaller set of enforceable primitives:

- **PreToolUse guards** for filesystem, bash, secret, production-risk policy, package mutation, shell-mediated secret reads, and adversarial command variants.
- **PostToolUse audit** that records tool calls, file mutations, and test evidence.
- **Stop gates** that prevent premature completion when tests are stale or evidence is missing.
- **Doctrine** as explicit authority.
- **Memory promotion** as evidence-backed continuity, not model vibes.
- **Bounded agents** with jurisdiction, model choice, effort, and tool restrictions.
- **Namespaced Claude Code skills** for structured workflows.

## Repository shape

```text
corcept/
  Cargo.toml                  # Rust workspace
  crates/                     # Runtime, guards, ledger, memory, doctrine, CLI, installer
  plugins/corcept/         # Claude Code plugin scaffold
  schemas/                    # JSON schemas for config, events, memory, doctrine, hook IO
  docs/adr/                   # Architecture decision records
  docs/subtasks/              # Completed implementation subtasks
  docs/                       # Product, architecture, API, plugin, security docs
  examples/                   # Hook input fixtures and example generated project
  tests/                      # Integration fixture notes
```

## Build

```bash
cargo build --workspace --all-targets
cargo test --workspace --all-targets
```

## Install into a target repo

```bash
cargo run -p create-corcept -- --path /path/to/repo --dry-run
cargo run -p create-corcept -- --path /path/to/repo
```

or with the CLI:

```bash
cargo run -p corcept-cli -- init --path /path/to/repo --dry-run
cargo run -p corcept-cli -- init --path /path/to/repo
```

## Test the plugin locally

```bash
claude --plugin-dir ./plugins/corcept
```

Plugin skills are namespaced, for example:

```text
/corcept:intake
/corcept:plan-change
/corcept:review
/corcept:ship
```

## Hook contract

The hook binaries in `plugins/corcept/bin/` delegate to the `corcept` CLI:

```text
SessionStart      -> corcept hook session-start
UserPromptSubmit  -> corcept hook user-prompt-submit
PreToolUse        -> corcept hook pretool-guard
PostToolUse       -> corcept hook posttool-audit
Stop              -> corcept hook stop-check
```

Each hook reads Claude Code hook JSON from stdin and writes Claude Code hook JSON to stdout.

## Current scaffold status

All planned root docs, ADRs, subtasks, crates, plugin assets, schema files, tests, hook wrappers, and wiring files are present in this scaffold. The hardening pass adds classifier-based Bash guards, secret-ish path detection, adversarial guard tests, and fast tail-line ledger append semantics. Rust was authored as a complete workspace, but this generated artifact was not compiled in the current sandbox because Rust/Cargo are not installed in the environment that produced the zip.
