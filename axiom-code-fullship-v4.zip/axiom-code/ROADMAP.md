---
title: Roadmap
description: Versioned roadmap for AXIOM Code Runtime.
seo:
  title: Roadmap - AXIOM Code Runtime
  description: Versioned roadmap for AXIOM Code Runtime.
  keywords: ['roadmap', 'mvp', 'runtime', 'AXIOM Code', 'Claude Code', 'Rust']
tags: ['roadmap', 'mvp', 'runtime']
status: complete
---


# Roadmap

## v0.1 scaffold-complete

- [x] Rust workspace.
- [x] CLI and installer crates.
- [x] Hook runtime.
- [x] Ledger, guard, memory, doctrine crates.
- [x] Claude Code plugin assets.
- [x] Root docs, ADRs, and subtasks.

## v0.2 verification hardening

- [ ] Run full CI in Rust-enabled environment.
- [ ] Add property tests for guard pattern matching.
- [ ] Add signed artifact release.
- [ ] Add marketplace manifest once distribution path is chosen.

## v0.3 team mode

- [ ] Team policy packs.
- [ ] Read-only MCP profiles.
- [ ] Audit report renderer.
- [ ] Memory expiry enforcement.
