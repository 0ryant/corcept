---
title: Implement CLI
description: Completed implementation subtask for AXIOM Code Runtime.
seo:
  title: Implement CLI - AXIOM Code completed subtask
  description: Completed implementation record for Implement CLI.
  keywords: [AXIOM Code, subtask, completed, scaffold, Rust, Claude Code]
tags: [subtask, completed, axiom-code, rust, claude-code]
status: complete
---

# Implement CLI

## Status

Complete.

## Outcome

Operator CLI and hook entrypoint were implemented.

## Evidence

See workspace files, crate sources, plugin assets, schemas, and root documentation in this scaffold.
