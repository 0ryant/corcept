---
title: Write skills
description: Completed implementation subtask for AXIOM Code Runtime.
seo:
  title: Write skills - AXIOM Code completed subtask
  description: Completed implementation record for Write skills.
  keywords: [AXIOM Code, subtask, completed, scaffold, Rust, Claude Code]
tags: [subtask, completed, axiom-code, rust, claude-code]
status: complete
---

# Write skills

## Status

Complete.

## Outcome

Canonical skills were written.

## Evidence

See workspace files, crate sources, plugin assets, schemas, and root documentation in this scaffold.
