---
title: Wire hooks
description: Completed implementation subtask for AXIOM Code Runtime.
seo:
  title: Wire hooks - AXIOM Code completed subtask
  description: Completed implementation record for Wire hooks.
  keywords: [AXIOM Code, subtask, completed, scaffold, Rust, Claude Code]
tags: [subtask, completed, axiom-code, rust, claude-code]
status: complete
---

# Wire hooks

## Status

Complete.

## Outcome

Claude Code hook config was wired to CLI wrappers.

## Evidence

See workspace files, crate sources, plugin assets, schemas, and root documentation in this scaffold.
