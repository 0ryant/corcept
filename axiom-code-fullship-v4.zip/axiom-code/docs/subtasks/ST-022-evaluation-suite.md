# ST-022: Evaluation suite

Status: completed  
Completed: 2026-05-18  
Tags: benchmark, evaluation, paired-run, SWE-bench, Terminal-Bench, correctness, reasoning, AXIOM

## Scope

- Add standalone AXIOM Eval Suite v0.1.
- Add runnable local governance, stop-gate, memory/doctrine, and mini-SWE harness checks.
- Add paired baseline-vs-AXIOM command runner.
- Add external benchmark adapter notes and preflight checks.
- Embed generated local results.

## Acceptance criteria

- Local deterministic eval runs with Python only.
- Results JSON and markdown report are generated.
- External benchmarks are represented as preflighted adapters.
- Scaffold contains ADR and subtask metadata.

## Result

Completed.
