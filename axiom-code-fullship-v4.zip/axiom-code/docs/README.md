---
title: AXIOM Code Docs Index
description: Documentation index for AXIOM Code Runtime.
seo:
  title: AXIOM Code documentation index
  description: Index of ADRs, subtasks, runtime docs, plugin docs, and governance material.
  keywords: [AXIOM Code, docs, ADR, Claude Code, Rust]
tags: [docs, index, axiom-code]
status: complete
---

# Docs Index

- `adr/` accepted architecture decisions.
- `subtasks/` completed implementation records.
- Root docs cover architecture, install, usage, API, plugin, governance, testing, security, release, roadmap, tasks, and changelog.
