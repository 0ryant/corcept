---
title: Testing strategy
description: Use crate unit tests, hook fixtures, runtime integration tests, and CI gates.
seo:
  title: Testing strategy - AXIOM Code ADR
  description: Use crate unit tests, hook fixtures, runtime integration tests, and CI gates.
  keywords: ['adr', 'testing', 'ci', 'AXIOM Code', 'ADR', 'Claude Code', 'Rust']
tags: ['adr', 'testing', 'ci']
status: accepted
---


# Testing strategy

## Status

Accepted.

## Context

AXIOM Code is intended to be a governed Claude Code runtime, not a broad prompt marketplace. The system must be inspectable, project-local by default, testable, and auditable.

## Decision

Use crate unit tests, hook fixtures, runtime integration tests, and CI gates.

## Consequences

Positive:

- The runtime has a clear trust model.
- Behavior can be verified with tests and ledger evidence.
- Plugin assets stay small and reviewable.
- Security-sensitive behavior lives in Rust instead of prompt prose.

Trade-offs:

- The scaffold is more engineering-heavy than a prompt pack.
- Users must build or install the CLI for hooks to execute.
- Policy tuning requires schema-aware changes rather than casual prompt edits.

## Completion

This ADR is implemented in the scaffold and linked to completed subtasks in `TASKS.md`.
