---
title: Operating Model
description: AXIOM operating model for Claude Code governed execution.
seo:
  title: AXIOM Code operating model
  description: Operating model for doctrine, memory, agents, hooks, and audit in AXIOM Code.
  keywords: [AXIOM, Claude Code, operating model, governance, memory, audit]
tags: [operating-model, governance, hooks, memory]
status: complete
---

# Operating Model

AXIOM Code treats Claude Code as an execution partner that needs boundaries. The model is:

```text
user intent -> intake -> plan -> bounded implementation -> test -> review -> audit -> ship
```

The runtime enforces hard boundaries through hooks and records evidence through the ledger.
