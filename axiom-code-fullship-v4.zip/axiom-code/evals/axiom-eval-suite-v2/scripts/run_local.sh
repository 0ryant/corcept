#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m axiom_eval run-local --out results/local
python -m axiom_eval preflight --out results/preflight.json
