#!/usr/bin/env bash
set -euo pipefail
python -m axiom_eval preflight --out results/preflight.json
python -m axiom_eval list-benchmarks --out results/benchmark-registry.json
python -m axiom_eval write-runbook --out results/external-runbook.md
