#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${BASELINE_CMD:?Set BASELINE_CMD}"
: "${AXIOM_CMD:?Set AXIOM_CMD}"
PLUGIN_DIR="${PLUGIN_DIR:-}"
python -m axiom_eval run-pair --baseline-cmd "$BASELINE_CMD" --axiom-cmd "$AXIOM_CMD" --plugin-dir "$PLUGIN_DIR" --out results/paired-mini-swe
