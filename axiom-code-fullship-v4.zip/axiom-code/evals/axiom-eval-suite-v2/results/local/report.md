# AXIOM Eval Report

Source: `/mnt/data/axiom-eval-results-v1/local/results.json`

## Local deterministic results

| Suite | Total | Passed | Failed | Accuracy |
|---|---:|---:|---:|---:|
| governance | 52 | 52 | 0 | 100.0% |
| stop_gate | 10 | 10 | 0 | 100.0% |
| memory_doctrine | 8 | 8 | 0 | 100.0% |
| mini_swe_oracle_noop | 3 | oracle 3 | noop 0 | oracle 100.0% |

## Guard latency

Calls: `10000`; median `19.442 µs`; p95 `47.807 µs`.

## Interpretation

The local benchmark is a policy and harness correctness benchmark, not a model-reasoning benchmark. It verifies that AXIOM's deterministic guard, stop, memory, and doctrine rules classify the current fixture set correctly, and that the mini-SWE harness can distinguish failing initial states from passing oracle patches.

## External benchmark status

SWE-bench, SWE-Skills-Bench, Terminal-Bench, LiveCodeBench, BFCL, and tau-bench adapters are included but require external infrastructure: Docker where applicable, the benchmark package/checkouts, and an agent/model command. They were not executed in this sandbox.
