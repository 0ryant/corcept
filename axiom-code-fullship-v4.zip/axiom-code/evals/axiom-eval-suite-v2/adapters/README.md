# External adapters

These adapters are intentionally command-template based rather than locked to one agent. AXIOM is a runtime/plugin layer, so the fair experiment is to run exactly the same model/agent command twice: once without AXIOM, once with AXIOM loaded.

Use `python -m axiom_eval preflight` to see which harness dependencies are present.
