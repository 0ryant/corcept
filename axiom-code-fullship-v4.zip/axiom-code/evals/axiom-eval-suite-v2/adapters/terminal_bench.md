# Terminal-Bench / Harbor adapter

Terminal-Bench is the runtime-layer benchmark. Use it to test whether AXIOM improves real terminal workflows, not just toy command classification.

Expected local preflight:

```bash
harbor datasets list
```

Experiment:

```text
baseline agent command: no AXIOM plugin/hooks
AXIOM agent command: AXIOM plugin/hooks enabled
```

Report task success and command-safety metrics together.
