---
title: axiom-doctrine
description: Doctrine loading, defaults, and validation for AXIOM Code.
seo:
  title: axiom-doctrine crate - AXIOM Code Runtime
  description: Doctrine loading, defaults, and validation for AXIOM Code.
  keywords: [AXIOM Code, axiom-doctrine, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-doctrine

Doctrine loading, defaults, and validation for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
