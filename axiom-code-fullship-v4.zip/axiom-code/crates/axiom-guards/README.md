---
title: axiom-guards
description: Deterministic guard evaluation for bash, filesystem, secrets, and stop gates.
seo:
  title: axiom-guards crate - AXIOM Code Runtime
  description: Deterministic guard evaluation for bash, filesystem, secrets, and stop gates.
  keywords: [AXIOM Code, axiom-guards, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-guards

Deterministic guard evaluation for bash, filesystem, secrets, and stop gates.

This crate is part of the AXIOM Code Runtime scaffold.
