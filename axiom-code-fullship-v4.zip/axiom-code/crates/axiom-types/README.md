---
title: axiom-types
description: Shared config, hook, event, memory, and doctrine types for AXIOM Code.
seo:
  title: axiom-types crate - AXIOM Code Runtime
  description: Shared config, hook, event, memory, and doctrine types for AXIOM Code.
  keywords: [AXIOM Code, axiom-types, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-types

Shared config, hook, event, memory, and doctrine types for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
