---
title: axiom-runtime
description: Project initialization, doctor, audit, and Claude Code hook orchestration for AXIOM Code.
seo:
  title: axiom-runtime crate - AXIOM Code Runtime
  description: Project initialization, doctor, audit, and Claude Code hook orchestration for AXIOM Code.
  keywords: [AXIOM Code, axiom-runtime, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-runtime

Project initialization, doctor, audit, and Claude Code hook orchestration for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
