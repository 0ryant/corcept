---
title: create-axiom-code
description: Dedicated project installer binary for AXIOM Code.
seo:
  title: create-axiom-code crate - AXIOM Code Runtime
  description: Dedicated project installer binary for AXIOM Code.
  keywords: [AXIOM Code, create-axiom-code, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# create-axiom-code

Dedicated project installer binary for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
