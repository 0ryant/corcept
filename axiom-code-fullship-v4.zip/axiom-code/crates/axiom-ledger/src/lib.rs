use anyhow::{Context, Result};
use axiom_types::LedgerEvent;
use chrono::{SecondsFormat, Utc};
use sha2::{Digest, Sha256};
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use uuid::Uuid;

pub fn ledger_path(root: impl AsRef<Path>) -> PathBuf {
    root.as_ref().join(".axiom").join("ledger").join("events.jsonl")
}

pub fn last_hash_path(root: impl AsRef<Path>) -> PathBuf {
    root.as_ref().join(".axiom").join("ledger").join("last_hash")
}

pub fn ensure_ledger(root: impl AsRef<Path>) -> Result<PathBuf> {
    let path = ledger_path(root.as_ref());
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).with_context(|| format!("creating ledger directory {}", parent.display()))?;
    }
    if !path.exists() {
        fs::write(&path, "").with_context(|| format!("creating ledger {}", path.display()))?;
    }
    let sidecar = last_hash_path(root.as_ref());
    if !sidecar.exists() {
        fs::write(&sidecar, "").with_context(|| format!("creating ledger sidecar {}", sidecar.display()))?;
    }
    Ok(path)
}

pub fn hash_event(event: &LedgerEvent) -> Result<String> {
    let mut clone = event.clone();
    clone.hash = None;
    let canonical = serde_json::to_string(&clone)?;
    let mut hasher = Sha256::new();
    hasher.update(canonical.as_bytes());
    Ok(format!("sha256:{}", hex::encode(hasher.finalize())))
}

pub fn read_events(root: impl AsRef<Path>) -> Result<Vec<LedgerEvent>> {
    let path = ledger_path(root);
    if !path.exists() {
        return Ok(Vec::new());
    }
    let raw = fs::read_to_string(&path).with_context(|| format!("reading ledger {}", path.display()))?;
    raw.lines()
        .filter(|line| !line.trim().is_empty())
        .map(|line| serde_json::from_str::<LedgerEvent>(line).context("parsing ledger event"))
        .collect()
}

pub fn last_hash(root: impl AsRef<Path>) -> Result<Option<String>> {
    let root = root.as_ref();
    let sidecar = last_hash_path(root);
    if sidecar.exists() {
        let raw = fs::read_to_string(&sidecar).with_context(|| format!("reading ledger sidecar {}", sidecar.display()))?;
        let trimmed = raw.trim();
        if !trimmed.is_empty() {
            return Ok(Some(trimmed.to_string()));
        }
    }

    let path = ledger_path(root);
    let Some(line) = last_nonempty_line(&path)? else { return Ok(None); };
    let event: LedgerEvent = serde_json::from_str(&line).context("parsing last ledger event")?;
    Ok(event.hash)
}

pub fn append_event(root: impl AsRef<Path>, mut event: LedgerEvent) -> Result<LedgerEvent> {
    let root = root.as_ref();
    let path = ensure_ledger(root)?;
    if event.id.trim().is_empty() {
        event.id = format!("evt_{}", Uuid::new_v4().simple());
    }
    if event.ts.trim().is_empty() {
        event.ts = Utc::now().to_rfc3339_opts(SecondsFormat::Millis, true);
    }
    event.prev_hash = last_hash(root)?;
    event.hash = Some(hash_event(&event)?);

    let mut file = OpenOptions::new().create(true).append(true).open(&path)?;
    writeln!(file, "{}", serde_json::to_string(&event)?)?;
    if let Some(hash) = &event.hash {
        fs::write(last_hash_path(root), hash.as_bytes())?;
    }
    Ok(event)
}

pub fn verify_hash_chain(root: impl AsRef<Path>) -> Result<bool> {
    let root = root.as_ref();
    let events = read_events(root)?;
    let mut previous: Option<String> = None;
    for event in &events {
        if event.prev_hash != previous {
            return Ok(false);
        }
        let expected = hash_event(event)?;
        if event.hash.as_deref() != Some(expected.as_str()) {
            return Ok(false);
        }
        previous = event.hash.clone();
    }
    if let Some(hash) = previous {
        fs::write(last_hash_path(root), hash.as_bytes())?;
    }
    Ok(true)
}

fn last_nonempty_line(path: &Path) -> Result<Option<String>> {
    if !path.exists() {
        return Ok(None);
    }
    let mut file = File::open(path).with_context(|| format!("opening ledger {}", path.display()))?;
    let mut pos = file.metadata()?.len();
    if pos == 0 {
        return Ok(None);
    }

    let mut buf = Vec::new();
    let mut byte = [0u8; 1];
    let mut seen_content = false;
    while pos > 0 {
        pos -= 1;
        file.seek(SeekFrom::Start(pos))?;
        file.read_exact(&mut byte)?;
        match byte[0] {
            b'\n' | b'\r' if !seen_content => continue,
            b'\n' | b'\r' => break,
            b => {
                seen_content = true;
                buf.push(b);
            }
        }
    }
    if buf.is_empty() {
        return Ok(None);
    }
    buf.reverse();
    Ok(Some(String::from_utf8(buf)?))
}

#[cfg(test)]
mod tests {
    use super::*;
    use axiom_types::AuthorityLevel;
    use std::collections::BTreeMap;

    fn event(kind: &str) -> LedgerEvent {
        LedgerEvent {
            id: String::new(),
            ts: String::new(),
            session_id: Some("s".to_string()),
            actor: "test".to_string(),
            event_type: kind.to_string(),
            authority_level: AuthorityLevel::L0Observe,
            tool: None,
            target: None,
            decision: None,
            decision_reason: None,
            evidence_refs: vec![],
            prev_hash: None,
            hash: None,
            metadata: BTreeMap::new(),
        }
    }

    #[test]
    fn appends_and_verifies_hash_chain() {
        let dir = tempfile::tempdir().unwrap();
        append_event(dir.path(), event("session_started")).unwrap();
        append_event(dir.path(), event("prompt_submitted")).unwrap();
        assert_eq!(read_events(dir.path()).unwrap().len(), 2);
        assert!(verify_hash_chain(dir.path()).unwrap());
    }

    #[test]
    fn sidecar_tracks_last_hash() {
        let dir = tempfile::tempdir().unwrap();
        let first = append_event(dir.path(), event("session_started")).unwrap();
        assert_eq!(last_hash(dir.path()).unwrap(), first.hash);
        assert!(last_hash_path(dir.path()).exists());
    }
}
