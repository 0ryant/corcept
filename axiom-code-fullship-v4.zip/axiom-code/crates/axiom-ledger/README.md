---
title: axiom-ledger
description: Hash-chained JSONL audit ledger for AXIOM Code.
seo:
  title: axiom-ledger crate - AXIOM Code Runtime
  description: Hash-chained JSONL audit ledger for AXIOM Code.
  keywords: [AXIOM Code, axiom-ledger, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-ledger

Hash-chained JSONL audit ledger for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
