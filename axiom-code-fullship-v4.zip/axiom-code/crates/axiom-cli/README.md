---
title: axiom-cli
description: Operator CLI and hook entrypoint for AXIOM Code.
seo:
  title: axiom-cli crate - AXIOM Code Runtime
  description: Operator CLI and hook entrypoint for AXIOM Code.
  keywords: [AXIOM Code, axiom-cli, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-cli

Operator CLI and hook entrypoint for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
