use anyhow::Result;
use axiom_memory::{new_candidate, promote_candidate, write_candidate};
use axiom_runtime::{audit, doctor, handle_hook, init_project, InitOptions};
use clap::{Parser, Subcommand};
use std::io::Read;
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(name = "axiom", version, about = "AXIOM Code Runtime CLI")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Debug, Subcommand)]
enum Commands {
    Init {
        #[arg(long, default_value = ".")]
        path: PathBuf,
        #[arg(long)]
        dry_run: bool,
        #[arg(long)]
        force: bool,
    },
    Doctor {
        #[arg(long, default_value = ".")]
        path: PathBuf,
    },
    Audit {
        #[arg(long, default_value = ".")]
        path: PathBuf,
    },
    Hook {
        event: String,
    },
    Memory {
        #[command(subcommand)]
        command: MemoryCommands,
    },
    Doctrine {
        #[command(subcommand)]
        command: DoctrineCommands,
    },
}

#[derive(Debug, Subcommand)]
enum MemoryCommands {
    Propose {
        #[arg(long, default_value = ".")]
        path: PathBuf,
        #[arg(long)]
        title: String,
        #[arg(long)]
        claim: String,
        #[arg(long, value_delimiter = ',')]
        evidence: Vec<String>,
    },
    Promote {
        #[arg(long, default_value = ".")]
        path: PathBuf,
        #[arg(long)]
        id: String,
        #[arg(long, default_value = "user")]
        approved_by: String,
    },
}

#[derive(Debug, Subcommand)]
enum DoctrineCommands {
    Validate {
        #[arg(long, default_value = ".")]
        path: PathBuf,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::Init { path, dry_run, force } => {
            let report = init_project(InitOptions { path, dry_run, force })?;
            println!("{}", serde_json::to_string_pretty(&report)?);
        }
        Commands::Doctor { path } => {
            println!("{}", serde_json::to_string_pretty(&doctor(path)?)?);
        }
        Commands::Audit { path } => {
            println!("{}", serde_json::to_string_pretty(&audit(path)?)?);
        }
        Commands::Hook { event } => {
            let mut input = String::new();
            std::io::stdin().read_to_string(&mut input)?;
            let output = handle_hook(&input, &event)?;
            println!("{}", serde_json::to_string(&output)?);
        }
        Commands::Memory { command } => match command {
            MemoryCommands::Propose { path, title, claim, evidence } => {
                let candidate = new_candidate(title, claim, evidence, "axiom-cli");
                let file = write_candidate(path, &candidate)?;
                println!("{}", serde_json::json!({"status":"created","id":candidate.id,"path":file}).to_string());
            }
            MemoryCommands::Promote { path, id, approved_by } => {
                let accepted = promote_candidate(path, &id, approved_by)?;
                println!("{}", serde_json::to_string_pretty(&accepted)?);
            }
        },
        Commands::Doctrine { command } => match command {
            DoctrineCommands::Validate { path } => {
                let warnings = axiom_doctrine::validate(path)?;
                println!("{}", serde_json::json!({"status": if warnings.is_empty() {"pass"} else {"warn"}, "warnings": warnings}).to_string());
            }
        },
    }
    Ok(())
}
