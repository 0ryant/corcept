---
title: axiom-memory
description: Evidence-backed memory candidate and promotion lifecycle for AXIOM Code.
seo:
  title: axiom-memory crate - AXIOM Code Runtime
  description: Evidence-backed memory candidate and promotion lifecycle for AXIOM Code.
  keywords: [AXIOM Code, axiom-memory, Rust, Claude Code, hooks, governance]
tags: [crate, rust, axiom-code, claude-code, hooks, governance]
status: complete
---

# axiom-memory

Evidence-backed memory candidate and promotion lifecycle for AXIOM Code.

This crate is part of the AXIOM Code Runtime scaffold.
