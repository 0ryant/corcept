---
title: AXIOM Integration Tests
description: Integration testing notes and fixture contract.
seo:
  title: AXIOM Code integration tests
  description: Integration tests for AXIOM Code hook runtime, installer, guards, ledger, memory, and doctrine.
  keywords: [AXIOM Code, integration tests, Rust, Claude Code hooks]
tags: [tests, integration, rust, hooks]
status: complete
---

# Integration Tests

The Rust unit tests live in each crate. This directory documents cross-crate scenarios that CI should exercise:

1. Initialize a temp repository with `create-axiom-code`.
2. Pipe `examples/fixtures/pretool-bash-rm-rf.json` into `axiom hook pretool-guard` and assert denial.
3. Pipe `examples/fixtures/pretool-bash-npm-install.json` and assert ask.
4. Pipe a PostToolUse edit event and assert a ledger `file_modified` event.
5. Pipe a Stop event after file modification and before tests, asserting block.
6. Propose memory with evidence and promote it.
7. Validate doctrine.
