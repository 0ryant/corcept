---
title: API Reference
description: Public Rust crate API and CLI command reference.
seo:
  title: API Reference - AXIOM Code Runtime
  description: Public Rust crate API and CLI command reference.
  keywords: ['api', 'rust', 'cli', 'runtime', 'AXIOM Code', 'Claude Code', 'Rust']
tags: ['api', 'rust', 'cli', 'runtime']
status: complete
---


# API Reference

## `axiom-types`

Shared data types:

- `AxiomConfig`
- `HookEnvelope`
- `HookOutput`
- `PermissionDecision`
- `LedgerEvent`
- `MemoryCandidate`
- `AcceptedMemory`
- `DoctrineRule`

## `axiom-ledger`

- `append_event(root, event)`
- `read_events(root)`
- `verify_hash_chain(root)`
- `last_hash(root)`

## `axiom-guards`

- `evaluate_pre_tool(input, config)`
- `evaluate_stop(root, stop_hook_active)`
- `extract_path(tool_input)`
- `extract_command(tool_input)`

## `axiom-runtime`

- `init_project(options)`
- `doctor(path)`
- `audit(path)`
- `handle_hook(raw_json, command)`

## CLI commands

```bash
axiom init
axiom doctor
axiom audit
axiom hook
axiom memory propose
axiom memory promote
axiom doctrine validate
```
