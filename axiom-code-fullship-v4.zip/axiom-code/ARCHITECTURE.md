---
title: Architecture
description: System architecture for AXIOM Code Runtime.
seo:
  title: Architecture - AXIOM Code Runtime
  description: System architecture for AXIOM Code Runtime.
  keywords: ['architecture', 'runtime', 'hooks', 'ledger', 'memory', 'doctrine', 'AXIOM Code', 'Claude Code', 'Rust']
tags: ['architecture', 'runtime', 'hooks', 'ledger', 'memory', 'doctrine']
status: complete
---


# Architecture

AXIOM Code is divided into four operational layers.

## 1. Claude Code plugin layer

Located at `plugins/axiom-code/`, this layer contains:

- `.claude-plugin/plugin.json` manifest.
- `skills/*/SKILL.md` namespaced skills.
- `agents/*.md` bounded subagents.
- `hooks/hooks.json` lifecycle wiring.
- `bin/*` wrapper scripts that delegate to the Rust CLI.

## 2. Rust runtime layer

The Rust workspace implements deterministic behavior that should not be left to prompts:

- `axiom-types`: shared config, hook, event, memory, and doctrine types.
- `axiom-ledger`: JSONL audit ledger and hash-chain verification.
- `axiom-guards`: bash/filesystem/secret/stop policy evaluation.
- `axiom-doctrine`: doctrine loading and validation.
- `axiom-memory`: candidate and accepted memory lifecycle.
- `axiom-runtime`: project init, doctor, audit, and hook orchestration.
- `axiom-cli`: operator CLI and hook entrypoint.
- `create-axiom-code`: dedicated installer binary.

## 3. Project governance layer

Generated projects receive:

```text
.claude/CLAUDE.md
.claude/settings.json
.axiom/config.yaml
.axiom/doctrine/*.md
.axiom/memory/{accepted,candidates,rejected}/
.axiom/ledger/events.jsonl
.axiom/reports/
```

## 4. Evidence layer

Every meaningful operation becomes structured evidence:

- prompt received
- task classified
- tool requested
- tool allowed/asked/denied
- file modified
- command executed
- test run
- audit completed
- memory proposed/promoted
- doctrine changed

This is the core difference between AXIOM and a prompt bundle. The runtime must be able to reconstruct what happened from the ledger.
