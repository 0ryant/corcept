# AXIOM Eval Runbook

## Local deterministic suite

```bash
cd evals/axiom-eval-suite-v2
python -m axiom_eval run-local --out results/local
python -m axiom_eval preflight --out results/preflight.json
python -m axiom_eval list-benchmarks --out results/benchmark-registry.json
python -m axiom_eval write-runbook --out results/external-runbook.md
```

## Paired mini-SWE

```bash
python -m axiom_eval run-pair   --suite mini-swe   --baseline-cmd 'claude --print "$AXIOM_TASK_PROMPT"'   --axiom-cmd 'claude --plugin-dir "$AXIOM_PLUGIN_DIR" --print "$AXIOM_TASK_PROMPT"'   --plugin-dir ../../plugins/axiom-code   --out results/paired-mini-swe
```

## Paired mini-reasoning

```bash
python -m axiom_eval run-pair   --suite mini-reasoning   --baseline-cmd 'claude --print "$AXIOM_TASK_PROMPT"'   --axiom-cmd 'claude --plugin-dir "$AXIOM_PLUGIN_DIR" --print "$AXIOM_TASK_PROMPT"'   --plugin-dir ../../plugins/axiom-code   --out results/paired-mini-reasoning
```

## External benchmark policy

Do not mix harnesses. Run baseline and AXIOM with the same model, same timeout, same temperature, same container image, same verifier and same task subset.
