---
title: Claude Code Plugin
description: Plugin layout, hooks, skills, agents, and packaging rules.
seo:
  title: Claude Code Plugin - AXIOM Code Runtime
  description: Plugin layout, hooks, skills, agents, and packaging rules.
  keywords: ['plugin', 'claude-code', 'hooks', 'skills', 'agents', 'AXIOM Code', 'Claude Code', 'Rust']
tags: ['plugin', 'claude-code', 'hooks', 'skills', 'agents']
status: complete
---


# Claude Code Plugin

The plugin is rooted at `plugins/axiom-code/`.

```text
plugins/axiom-code/
  .claude-plugin/plugin.json
  skills/*/SKILL.md
  agents/*.md
  hooks/hooks.json
  bin/*
  settings.json
```

## Hook wrappers

The plugin does not embed policy in shell. Every wrapper delegates to Rust:

```text
axiom-session-start       -> axiom hook session-start
axiom-user-prompt-submit  -> axiom hook user-prompt-submit
axiom-pretool-guard       -> axiom hook pretool-guard
axiom-posttool-audit      -> axiom hook posttool-audit
axiom-stop-check          -> axiom hook stop-check
```

## Skill policy

Side-effect skills use `disable-model-invocation: true`. This includes:

- `ship`
- `memory-promote`
- `doctrine-add`
- `audit`

## Agent policy

Agents declare:

- `name`
- `description`
- `model`
- `effort`
- `maxTurns`
- `tools` or `disallowedTools`

Plugin agents avoid unsupported plugin-agent fields and keep permission enforcement in hooks.
