---
title: AXIOM Code Plugin
description: Claude Code plugin for AXIOM governed runtime.
seo:
  title: AXIOM Code Plugin - Claude Code hooks, skills, and agents
  description: Claude Code plugin scaffold containing AXIOM skills, agents, lifecycle hooks, and CLI wrappers.
  keywords: [Claude Code plugin, AXIOM Code, hooks, skills, agents, governance]
tags: [plugin, claude-code, hooks, skills, agents, axiom-code]
status: complete
---

# AXIOM Code Plugin

Load locally with:

```bash
claude --plugin-dir ./plugins/axiom-code
```

The plugin expects `axiom` to be available on PATH. Build and install the CLI with:

```bash
cargo install --path crates/axiom-cli
```
