---
title: Usage
description: Operational usage patterns for AXIOM CLI, hooks, skills, agents, memory, and doctrine.
seo:
  title: Usage - AXIOM Code Runtime
  description: Operational usage patterns for AXIOM CLI, hooks, skills, agents, memory, and doctrine.
  keywords: ['usage', 'cli', 'skills', 'agents', 'hooks', 'AXIOM Code', 'Claude Code', 'Rust']
tags: ['usage', 'cli', 'skills', 'agents', 'hooks']
status: complete
---


# Usage

## CLI

```bash
axiom init --path . --dry-run
axiom doctor --path .
axiom audit --path .
axiom memory propose --path . --title "Convention" --claim "Claim text" --evidence "src/lib.rs:10"
axiom memory promote --path . --id mem_...
axiom doctrine validate --path .
```

## Claude Code skills

Use the plugin with:

```bash
claude --plugin-dir ./plugins/axiom-code
```

Then invoke:

```text
/axiom-code:intake
/axiom-code:map-codebase
/axiom-code:plan-change
/axiom-code:implement
/axiom-code:review
/axiom-code:test
/axiom-code:threat-model
/axiom-code:audit
/axiom-code:ship
```

## Hook behavior

- `PreToolUse` blocks or asks before risky actions.
- `PostToolUse` records tool results and marks tests.
- `Stop` blocks premature completion if source changed after tests.
- `UserPromptSubmit` injects scoped governance reminders.
- `SessionStart` loads doctrine/memory context.

## Memory

Memory is never promoted directly from model output. It moves through:

```text
observation -> candidate -> accepted memory -> doctrine, if explicitly approved
```
